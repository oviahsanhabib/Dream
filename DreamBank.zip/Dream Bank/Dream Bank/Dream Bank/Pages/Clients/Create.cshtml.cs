using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Dream_Bank.Pages.Clients
{
    public class CreateModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {
            clientInfo.name = Request.Form["name"];
            clientInfo.account_no = Request.Form["account_no"];
            clientInfo.account_type = Request.Form["account_type"];
            clientInfo.gender = Request.Form["gender"];
            clientInfo.dob = Request.Form["dob"];
            clientInfo.address = Request.Form["address"];
            clientInfo.city = Request.Form["city"];
            clientInfo.state = Request.Form["state"];
            clientInfo.postal = Request.Form["postal"];
            clientInfo.country = Request.Form["country"];
            clientInfo.email = Request.Form["email"];
            clientInfo.phone = Request.Form["phone"];
            clientInfo.ssn = Request.Form["ssn"];
            clientInfo.indeposit = Request.Form["indeposit"];

            if (clientInfo.name.Length == 0)
            {
                errorMessage = "All fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=ahsan;Initial Catalog=DreamBank;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "INSERT INTO clients " +
                                   "(name, account_no, account_type, gender, dob, address, city, state, postal, country, email, phone, ssn, indeposit) values " +
                                   "(@name, @account_no, @account_type, @gender, @dob, @address, @city, @state, @postal, @country, @email, @phone, @ssn, @indeposit);";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", clientInfo.name);
                        command.Parameters.AddWithValue("@account_no", clientInfo.account_no);
                        command.Parameters.AddWithValue("@account_type", clientInfo.account_type);
                        command.Parameters.AddWithValue("@gender", clientInfo.gender);
                        command.Parameters.AddWithValue("@dob", clientInfo.dob);
                        command.Parameters.AddWithValue("@address", clientInfo.address);
                        command.Parameters.AddWithValue("@city", clientInfo.city);
                        command.Parameters.AddWithValue("@state", clientInfo.state);
                        command.Parameters.AddWithValue("@postal", clientInfo.postal);
                        command.Parameters.AddWithValue("@country", clientInfo.country);
                        command.Parameters.AddWithValue("@email", clientInfo.email);
                        command.Parameters.AddWithValue("@phone", clientInfo.phone);
                        command.Parameters.AddWithValue("@ssn", clientInfo.ssn);
                        command.Parameters.AddWithValue("@indeposit", clientInfo.indeposit);


                        command.ExecuteNonQuery();
                    }
                }

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            clientInfo.name = ""; clientInfo.account_no = ""; clientInfo.account_type = ""; clientInfo.gender = ""; clientInfo.dob = "";
            clientInfo.address = ""; clientInfo.city = ""; clientInfo.state = ""; clientInfo.postal = ""; clientInfo.country = "";
            clientInfo.email = ""; clientInfo.phone = ""; clientInfo.ssn = ""; clientInfo.indeposit = "";
            successMessage = "New Client Added";
            Response.Redirect("/Clients/Index");

        }
    }
}

