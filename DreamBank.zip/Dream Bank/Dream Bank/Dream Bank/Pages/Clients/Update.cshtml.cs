using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Dream_Bank.Pages.Clients
{
    public class UpdateModel : PageModel
    {
        public List<ClientInfo> listClients = new List<ClientInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=ahsan;Initial Catalog=DreamBank;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "Select * from clients";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ClientInfo clientInfo = new ClientInfo();
                                clientInfo.id = "" + reader.GetInt32(0);
                                clientInfo.name = reader.GetString(1);
                                clientInfo.account_no = reader.GetString(2);
                                clientInfo.account_type = reader.GetString(3);
                                clientInfo.gender = reader.GetString(4);
                                clientInfo.dob = reader.GetString(5);
                                clientInfo.address = reader.GetString(6);
                                clientInfo.city = reader.GetString(7);
                                clientInfo.state = reader.GetString(8);
                                clientInfo.postal = reader.GetString(9);
                                clientInfo.country = reader.GetString(10);
                                clientInfo.email = reader.GetString(11);
                                clientInfo.phone = reader.GetString(12);
                                clientInfo.ssn = reader.GetString(13);
                                clientInfo.indeposit = "" + reader.GetInt32(14);
                                clientInfo.created_at = reader.GetDateTime(15).ToString();

                                listClients.Add(clientInfo);

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }


        }
    }


    public class ClientInfo2
    {
        public String id;
        public String name;
        public String account_no;
        public String account_type;
        public String gender;
        public String dob;
        public String address;
        public String city;
        public String state;
        public String postal;
        public String country;
        public String email;
        public String phone;
        public String ssn;
        public String indeposit;
        public String created_at;
    }
}
