using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Dream_Bank.Pages.Clients
{
    public class DepositModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
            String id = Request.Query["id"];

            try
            {
                String connectionString = "Data Source=ahsan;Initial Catalog=DreamBank;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "Select * from clients where id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                clientInfo.id = "" + reader.GetInt32(0);
                                clientInfo.name = reader.GetString(1);
                                clientInfo.account_no = reader.GetString(2);
                                clientInfo.account_type = reader.GetString(3);
                                clientInfo.email = reader.GetString(11);
                                clientInfo.phone = reader.GetString(12);


                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }


        public void OnPost()
        {
            clientInfo.id = Request.Form["id"];
            clientInfo.name = Request.Form["name"];
            clientInfo.account_no = Request.Form["account_no"];
            clientInfo.account_type = Request.Form["account_type"];
            clientInfo.email = Request.Form["email"];
            clientInfo.phone = Request.Form["phone"];
            clientInfo.indeposit = Request.Form["indeposit"];



            try
            {
                String connectionString = "Data Source=ahsan;Initial Catalog=DreamBank;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "update clients " +
                                   "set indeposit= indeposit+ @indeposit " +
                                   "where id=@id";

                    

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", clientInfo.id);
                        command.Parameters.AddWithValue("@name", clientInfo.name);
                        command.Parameters.AddWithValue("@account_no", clientInfo.account_no);
                        command.Parameters.AddWithValue("@account_type", clientInfo.account_type);
                        command.Parameters.AddWithValue("@email", clientInfo.email);
                        command.Parameters.AddWithValue("@phone", clientInfo.phone);
                        command.Parameters.AddWithValue("@indeposit", clientInfo.indeposit);

                        command.ExecuteNonQuery();


                    }
                }

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            Response.Redirect("/Clients/Index");
        }
    }
}
