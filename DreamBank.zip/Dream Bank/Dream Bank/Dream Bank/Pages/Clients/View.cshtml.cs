using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Dream_Bank.Pages.Clients
{
    public class ViewModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
            String id = Request.Query["id"];

            try
            {
                String connectionString = "Data Source=ahsan;Initial Catalog=DreamBank;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "Select * from clients where id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                clientInfo.id = "" + reader.GetInt32(0);
                                clientInfo.name = reader.GetString(1);
                                clientInfo.account_no = reader.GetString(2);
                                clientInfo.account_type = reader.GetString(3);
                                clientInfo.gender = reader.GetString(4);
                                clientInfo.dob = reader.GetString(5);
                                clientInfo.address = reader.GetString(6);
                                clientInfo.city = reader.GetString(7);
                                clientInfo.state = reader.GetString(8);
                                clientInfo.postal = reader.GetString(9);
                                clientInfo.country = reader.GetString(10);
                                clientInfo.email = reader.GetString(11);
                                clientInfo.phone = reader.GetString(12);
                                clientInfo.ssn = reader.GetString(13);
                                clientInfo.indeposit = "" + reader.GetInt32(14);

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }


    }
}
