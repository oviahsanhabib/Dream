﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Dream_Bank.Migrations
{
    public partial class AddedPhotoUrl : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
